package logic

import "github.com/google/wire"

var WireSet = wire.NewSet(
	NewAccountLogic,
	NewHashLogic,
	NewTokenLogic,
	NewDownloadTaskLogic,
	NewHTTPDownloader,
)
